package com.amit.Webhook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class WebhookApplication  {
	public static AnnotationConfigApplicationContext context;
	public static void sendData(String queueName,String data) {
		MessageSender ms = context.getBean(MessageSender.class);
        ms.sendMessage(queueName, "test message");
	}	

    @Bean
    public ConnectionFactory connectionFactory() {
        ConnectionFactory connectionFactory =
                new ActiveMQConnectionFactory("vm://localhost");
        return connectionFactory;
    }

	public static void main(String[] args)  {
		SpringApplication.run(WebhookApplication.class, args);

		context= new AnnotationConfigApplicationContext(WebhookApplication.class);

        String queueName = "example.queue";
        String data="BRN;Payment;SGN";
        WebhookApplication.sendData(queueName, data);
	    
        
      /* try { 
       Class.forName("oracle.jdbc.driver.OracleDriver");  
        
      //step2 create  the connection object  
      Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","oracle");  
        
      //step3 create the statement object  
      Statement stmt=con.createStatement();  
        
      //step4 execute query  
      ResultSet rs=stmt.executeQuery("select  from emp");
      while(rs.next())  
    	  data=rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3);
      WebhookApplication.sendData(queueName, data);
    	    
    	  //step5 close the connection object  
    	  con.close();  
       }catch(Exception e) {
    	   e.printStackTrace();
       }*/
        
        

        MessageReceiver mr = context.getBean(MessageReceiver.class);
        mr.receiveMessage(queueName);
    }
}